$Id: $

jcgm -- An open source Java implementation to interpret and render Computer
Graphics Metafile (CGM) graphics files.

For more information: http://jcgm.sourceforge.net